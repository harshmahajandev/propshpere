import VillaMapView from '../components/VillaMapView'

export default function VillaMapPage() {
  return <VillaMapView />
}